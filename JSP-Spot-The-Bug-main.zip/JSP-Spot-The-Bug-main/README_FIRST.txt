JSP SPOT THE BUG - READY TO RUN
================================

FASTEST METHOD
--------------

1. Extract this ZIP.

2. Open the extracted folder:
   JSP_Spot_The_Bug_READY

3. Double-click:
   RUN_PROJECT.bat

4. Wait until Maven shows BUILD SUCCESS.

5. Tomcat will restart automatically.

6. Chrome should open:
   http://localhost:8080/spot-the-bug-jsp/

7. Enter:
   Ravi

8. Click Submit.

EXPECTED RESULT
---------------

Welcome Ravi

Request Scope User: Ravi
Session Scope User: Ravi


IMPORTANT
---------

RUN_PROJECT.bat is already configured for the paths you used:

JAVA:
C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot

MAVEN:
C:\Users\shaik Taj Abjal\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16

TOMCAT:
C:\Users\shaik Taj Abjal\Downloads\apache-tomcat-10.1.59-windows-x64\apache-tomcat-10.1.59


IF RUN_PROJECT.BAT DOES NOT WORK
--------------------------------

Open VS Code in this folder and run:

mvn clean package

Then copy:

target\spot-the-bug-jsp.war

to:

C:\Users\shaik Taj Abjal\Downloads\apache-tomcat-10.1.59-windows-x64\apache-tomcat-10.1.59\webapps

Before copying, delete old:
spot-the-bug-jsp
spot-the-bug-jsp.war

Then start Tomcat and open:

http://localhost:8080/spot-the-bug-jsp/


ASSIGNMENT BUGS COVERED
-----------------------

1. JSP Declaration / Thread Safety

Wrong:
<%! String username; %>

Correct:
<%
    String username = request.getParameter("username");
%>

Reason:
A declaration becomes a Servlet instance variable and may be shared by
multiple request threads. A local variable is request-specific.


2. jsp:forward vs Redirect

<jsp:forward>:
- Server side
- Same request
- Request attributes are preserved
- Browser URL does not change

response.sendRedirect():
- Client side
- Creates a new request
- Old request attributes are not preserved
- Browser URL changes


3. requestScope vs sessionScope

request.setAttribute(...)
is read from the request.

session.setAttribute(...)
is read from the session.

This project demonstrates both correctly.
