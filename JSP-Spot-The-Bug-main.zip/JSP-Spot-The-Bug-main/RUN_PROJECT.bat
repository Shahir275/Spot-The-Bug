@echo off
title JSP Spot The Bug - Build and Run
echo ==========================================
echo JSP SPOT THE BUG - BUILD AND RUN
echo ==========================================
echo.

set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot"
set "MAVEN_HOME=C:\Users\shaik Taj Abjal\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16"
set "PATH=%MAVEN_HOME%\bin;%JAVA_HOME%\bin;%PATH%"
set "TOMCAT_HOME=C:\Users\shaik Taj Abjal\Downloads\apache-tomcat-10.1.59-windows-x64\apache-tomcat-10.1.59"

echo [1/6] Checking Java...
"%JAVA_HOME%\bin\java.exe" -version
if errorlevel 1 (
    echo.
    echo ERROR: Java path is not correct.
    pause
    exit /b 1
)

echo.
echo [2/6] Checking Maven...
call "%MAVEN_HOME%\bin\mvn.cmd" -version
if errorlevel 1 (
    echo.
    echo ERROR: Maven path is not correct.
    pause
    exit /b 1
)

echo.
echo [3/6] Building JSP project...
cd /d "%~dp0"
call "%MAVEN_HOME%\bin\mvn.cmd" clean package
if errorlevel 1 (
    echo.
    echo ERROR: Maven build failed.
    pause
    exit /b 1
)

echo.
echo [4/6] Stopping old Tomcat...
if exist "%TOMCAT_HOME%\bin\shutdown.bat" (
    call "%TOMCAT_HOME%\bin\shutdown.bat"
    timeout /t 3 /nobreak >nul
) else (
    echo ERROR: Tomcat folder was not found:
    echo %TOMCAT_HOME%
    pause
    exit /b 1
)

echo.
echo [5/6] Removing old deployment and copying new WAR...
if exist "%TOMCAT_HOME%\webapps\spot-the-bug-jsp" (
    rmdir /s /q "%TOMCAT_HOME%\webapps\spot-the-bug-jsp"
)

if exist "%TOMCAT_HOME%\webapps\spot-the-bug-jsp.war" (
    del /q "%TOMCAT_HOME%\webapps\spot-the-bug-jsp.war"
)

copy /y "%~dp0target\spot-the-bug-jsp.war" "%TOMCAT_HOME%\webapps\spot-the-bug-jsp.war"
if errorlevel 1 (
    echo ERROR: Could not copy WAR to Tomcat.
    pause
    exit /b 1
)

echo.
echo [6/6] Starting Tomcat...
call "%TOMCAT_HOME%\bin\startup.bat"

echo.
echo Waiting for Tomcat to deploy the application...
timeout /t 6 /nobreak >nul

echo.
echo Opening application...
start "" "http://localhost:8080/spot-the-bug-jsp/"

echo.
echo ==========================================
echo DONE
echo ==========================================
echo Enter a name such as Ravi and click Submit.
echo Expected:
echo Welcome Ravi
echo Request Scope User: Ravi
echo Session Scope User: Ravi
echo.
pause
